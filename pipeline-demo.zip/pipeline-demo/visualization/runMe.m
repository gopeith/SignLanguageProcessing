x = h5read('../data/keypoints-filt.h5','/rec01')';

skeletonDisp(x)
